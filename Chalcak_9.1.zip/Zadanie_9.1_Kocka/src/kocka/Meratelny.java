package kocka;

public interface Meratelny
{
    double getPriemernaHodnaHodnota();
    int hod();
}
