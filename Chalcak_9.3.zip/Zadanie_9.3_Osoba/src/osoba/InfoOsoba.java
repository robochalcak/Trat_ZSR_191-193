package osoba;

public interface InfoOsoba
{
    void setMeno(String meno);
    void setVyska(double vyska);
    String getMeno();
    double getVyska();
}
