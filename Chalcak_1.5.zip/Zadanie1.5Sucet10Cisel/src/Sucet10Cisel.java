public class Sucet10Cisel // class name
{

    public static void main(String[] args) // declaration of main, necessary for running each program in Java
    {
        System.out.println(1+2+3+4+5+6+7+8+9+10);//calling method println for the output.
    }

}
