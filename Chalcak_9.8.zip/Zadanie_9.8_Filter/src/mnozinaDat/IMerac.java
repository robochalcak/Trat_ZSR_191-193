package mnozinaDat;

public interface IMerac
{
    double zmeraj(Object objekt);
}
