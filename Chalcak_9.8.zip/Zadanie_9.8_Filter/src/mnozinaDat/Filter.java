package mnozinaDat;

public interface Filter
{
    boolean akceptuje(Object objekt);
}
