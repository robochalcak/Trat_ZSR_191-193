package mnozinaDat;

public interface IMeratelny
{
    double getMiera();
}
