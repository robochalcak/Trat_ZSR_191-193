public class Sucet10Zlomkov //class declaration
{
    public static void main(String[] args) //Necessary for each program
    {
        System.out.println(1/1.0 + 1/2.0+1/3.0+1/4.0+1/5.0+1/6.0+1/7.0+1/8.0+1/9.0+1/10.0);//calling function for
        // printing console output

        //If we want to make an operation with fractional numbers, is very necessary to divide fraction with real
        // numbers like double or float, because division with whole numbers like integers produces wrong results,
        // because the fractional part is omitted.
    }
}
