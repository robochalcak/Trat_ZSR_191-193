package zaverecnyProjekt.vygenerujId;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface VygenerujId
{
    void vygenerujId(Object obj) throws FileNotFoundException, ClassNotFoundException, IOException;
  
}
