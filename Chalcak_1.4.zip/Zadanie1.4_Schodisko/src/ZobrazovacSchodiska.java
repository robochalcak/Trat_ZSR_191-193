public class ZobrazovacSchodiska //class declaration
{

    public static void main(String[] args) // main()declaration
    {
        System.out.println("                +---+"); // printing stairs
        System.out.println("                |   |");
        System.out.println("            +---+---+");
        System.out.println("            |   |   |");
        System.out.println("        +---+---+---+");
        System.out.println("        |   |   |   |");
        System.out.println("    +---+---+---+---+");
        System.out.println("    |   |   |   |   |");
        System.out.println("+---+---+---+---+---+");
        System.out.println("|   |   |   |   |   |");
        System.out.println("+---+---+---+---+---+");
    }
}

