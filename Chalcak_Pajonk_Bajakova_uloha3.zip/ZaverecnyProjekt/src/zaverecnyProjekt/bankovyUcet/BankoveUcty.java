package zaverecnyProjekt.bankovyUcet;

import java.util.ArrayList;

/**
 * Trieda služí na uchovavanie sporiacích a bežných účtov. Výkonáva základne
 * operácie s nimi a vrácia rôzne štatistické hodnoty a informácie o účtoch
 * 
 * @author Robert Chalcak Tomáš Pajonk, Zuzana Bajakova
 */

public class BankoveUcty
{

   private ArrayList<BankovyUcet> ucty; // uchovava bežné a sporiace účty

   /**
    * Vytvára objekt Bankové účty bez použitia parametrov
    */
   public BankoveUcty()
   {
      ucty = new ArrayList<BankovyUcet>();
   }

   /**
    * Vygeneruje unikatné ide pozostavajúce z Stringov, ktoré označujú či ide o
    * bežný alebo sporiaci účet
    * 
    * @param ucet
    *           učet, pre ktorý je vygenerovaný Identifikator
    */
   public void vygenerujId(BankovyUcet ucet)
   {
      if (ucet.getTypUctu().equalsIgnoreCase("sporiaci"))
      {
         String id = "spUc";
         id += ucty.size() + 1;
         ucet.setId(id);
         id = "spUc";
      }
      else
      {
         String id = "bezUc";
         id += ucty.size() + 1;
         ucet.setId(id);
         id = "bezUc";
      }
   }

   /**
    * Pridavá učet do zoznamu, ktorý tvorí ArrayList a pred tým prideli id účtu
    * 
    * @param ucet
    *           , ktorý sa má prídat do zoznamu
    */
   public void pridajUcet(BankovyUcet ucet)
   {
      vygenerujId(ucet);
      ucty.add(ucet);
   }

   /**
    * Vykonáva prepis zmeneho učtu na konkretnom indexe v ArrayListe
    * 
    * @param novyUcet
    *           prepíše účet na konkretnej pozicii
    * @param index
    *           špecifikuje konkretnú poziciu v ArryListe
    */
   public void urobZmenuNaUcte(BankovyUcet novyUcet, int index)
   {
      if (index < 0 || index > ucty.size() - 1)
      {
         System.out.println("Ziaden ucet neexistuje!!!");
         return;
      }
      ucty.set(index, novyUcet);
   }

   /**
    * Vyhlada ucet v zozname s pouzitim integeru, ktorý je rovnaký aj pre
    * klienta
    * 
    * @param ajKlientId
    *           integer, ktory je rovnaky aj pre klienta takze vie sparovat
    *           klienta s jeho uctom
    * @return najdený účet
    */
   public BankovyUcet vyhladajUcet(int ajKlientId)
   {
      BankovyUcet najdeny = null;

      if (jePrazdnyBU())
      {
         System.out.println("Ziaden ucet!!!");
      }
      for (int i = 0; i < ucty.size(); i++)
      {
         if (ajKlientId == ucty.get(i).getRovnakeId())
         {
            najdeny = ucty.get(i);
         }
      }
      return najdeny;
   }

   /**
    * Vrácia poziciu účtu na základe indentifikatora, ktorý je rovnaký aj pre
    * klienta
    * 
    * @param ajKlientId
    *           jedinenčné číslo, ktoré je zhodné aj u klienta
    * @return pozicia účtu v ArrayListe
    */
   public int getIndexBu(int ajKlientId)
   {

      if (jePrazdnyBU())
      {
         System.out.println("Ziaden ucet!!!");
         return -1;
      }
      for (int i = 0; i < ucty.size(); i++)
      {
         if (ajKlientId == ucty.get(i).getRovnakeId())
         {
            return i;
         }
      }
      return -1;
   }

   /**
    * Vrácia celkových doposiaľ registrovaných účtov
    * 
    * @return počet účtov
    */
   public int getPocetBU()
   {
      return ucty.size();
   }

   /**
    * Vypíše kompletný zoznám účtov
    * 
    * @return
    */
   public String vratZoznamUctov()
   {
      String all = "------------------\n";
      all += "|  BEZNE ÚČTY    |\n";
      all += "------------------\n";

      for (int i = 0; i < ucty.size(); i++)
      {
         all += ucty.get(i) + "\n";
         all += "___________________\n";
      }
      all += "<><><><><>><><><><>\n";
      return all;
   }

   /**
    * Tak ako predchádzajúca metóda vracia formatovaný vystup všetkých účtov
    */
   public String toString()
   {
      String all = "";
      all += vratZoznamUctov();
      return all;

   }

   /**
    * Skontroluje čí v ArrazListe je nejaký účet
    * 
    * @return true ak nie je žiadný účet,opačne vracia false
    */
   public boolean jePrazdnyBU()
   {
      return ucty.size() == 0;
   }

}
