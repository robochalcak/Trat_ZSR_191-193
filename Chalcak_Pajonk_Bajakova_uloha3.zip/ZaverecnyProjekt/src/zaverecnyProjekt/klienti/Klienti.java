package zaverecnyProjekt.klienti;

import java.util.ArrayList;

import zaverecnyProjekt.vygenerujId.VygenerujId;

/**
 * Trieda uchovava všetkých klientov bánky v zozname
 * 
 * @author Robert Chalcak Tomas Pajonk, Zuzana Bajakova
 */

public class Klienti implements VygenerujId
{
   private ArrayList<Klient> klienti; // uchovava všetkých klientov banky

   /**
    * Vytvára prazdný objekt zoznamu klientov
    */
   public Klienti()
   {
      klienti = new ArrayList<Klient>();
   }

   /**
    * Vygeneruje jedinenčné id pre klienta
    */
   @Override
   public void vygenerujId(Object obj)
   {
      Klient klient = (Klient) obj;
      String id = "KLBO";
      id += klienti.size() + 1;
      klient.setId(id);
      id = "KLBO";

   }

   /**
    * Pridava klienta do zoznamu, pred tým mu prídeli ID
    * 
    * @param klient
    *           ktorý je pridaný do zoznamu
    */
   public void pridajKlienta(Klient klient)
   {
      vygenerujId(klient);
      klienti.add(klient);
   }

   /**
    * Vyhlada klienta podla parametrov
    * 
    * @param priezvisko
    *           klienta
    * @param rodneCislo
    *           klienta
    * @return vrati najdeneho klienta
    */
   public Klient vyhladajKlienta(String priezvisko, long rodneCislo)
   {
      Klient najdeny = new Klient();

      for (int i = 0; i < klienti.size(); i++)
      {
         if (priezvisko.equalsIgnoreCase(klienti.get(i).getPriezvisko())
               && rodneCislo == klienti.get(i).getRodneCislo())
         {
            najdeny = klienti.get(i);
         }
      }
      return najdeny;
   }

   /**
    * Vrati index - poziciu klienta v ArrayListe na základe parametrov
    * 
    * @param priezvisko
    *           klienta
    * @param rodneCislo
    *           klienta
    * @return pozicia klienta
    */
   public int getIndexKlienta(String priezvisko, long rodneCislo)
   {

      for (int i = 0; i < klienti.size(); i++)
      {
         if (priezvisko.equalsIgnoreCase(klienti.get(i).getPriezvisko())
               && rodneCislo == klienti.get(i).getRodneCislo())
         {
            return i;
         }
      }
      return -1;
   }

   /**
    * Vymaze klienta zo zoznamu a nasledne ho vrati parameter
    * 
    * @param index
    *           pozicia klienta, ktorá má byť vymazana
    * @return vymazaný klient
    */
   public Klient vymazKlienta(int index)
   {
      Klient naVymazanie = klienti.get(index);
      klienti.remove(index);
      return naVymazanie;
   }

   /**
    * Vymaze klienta podla parametrov
    * 
    * @param priezvisko
    *           klienta
    * @param rodneCislo
    *           klienta
    * @return vymazaného klienta
    */
   public Klient vymazKliena(String priezvisko, long rodneCislo)
   {
      Klient vymazany = null;
      for (int i = 0; i < klienti.size(); i++)
      {
         if (priezvisko.equalsIgnoreCase(klienti.get(i).getPriezvisko())
               && rodneCislo == klienti.get(i).getRodneCislo())
         {
            vymazany = vymazKlienta(i);
            vymazKlienta(i);
         }
      }
      return vymazany;
   }

   /**
    * Overí ci zadané parametre patria klientovi, či nie
    * 
    * @param priezvisko
    * @param rodneCislo
    * @return false alebo true
    */
   public boolean jeKlient(String priezvisko, long rodneCislo)
   {
      return vyhladajKlienta(priezvisko, rodneCislo).getPriezvisko()
            .equalsIgnoreCase(priezvisko)
            && vyhladajKlienta(priezvisko, rodneCislo).getRodneCislo() == rodneCislo;
   }

   /**
    * Vratí všetkých klientov banky vo formatovanom vystupe
    */
   public String toString()
   {
      String all = "----------------------------------\n";
      all += "|          NAŠÍ KLIENTI          |\n";
      all += "----------------------------------\n";
      for (int i = 0; i < klienti.size(); i++)
      {
         all += klienti.get(i) + "\n";
         all += "_________________________________\n";
      }
      all += "<><><><><><><><><><><><><><><><><>\n";

      return all;
   }

}
