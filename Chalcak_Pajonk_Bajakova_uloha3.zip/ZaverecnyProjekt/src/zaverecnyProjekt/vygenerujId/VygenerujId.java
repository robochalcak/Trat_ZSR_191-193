package zaverecnyProjekt.vygenerujId;

public interface VygenerujId
{
    void vygenerujId(Object obj);
}
