
public class Main
{
    public static void main(String[]args)
    {
        System.out.println("+----------------+");
        System.out.println("| Róbert Chalčák |");
        System.out.println("+----------------+");
    }
}