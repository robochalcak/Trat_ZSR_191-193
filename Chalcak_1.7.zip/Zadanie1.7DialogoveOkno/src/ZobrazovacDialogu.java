import javax.swing.JOptionPane; //Necessary for message dialog from  JOptionPane

public class ZobrazovacDialogu //class declaration
{
    public static void main(String[] args)//main method necessary for running each program
    {
        JOptionPane.showMessageDialog(null, "Nazdar Robert :-)");//calling output via message dialog
        System.exit(0); //successfully terminated program without any error
    }
}
