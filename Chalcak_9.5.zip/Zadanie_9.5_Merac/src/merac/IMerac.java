package merac;

public interface IMerac
{
    double zmeraj(Object object);
}
