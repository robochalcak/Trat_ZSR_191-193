package merac;

public interface IMeratelny
{
    double getMiera();
}
