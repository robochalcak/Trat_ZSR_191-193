package mnozinaDat;

/**
 * This interface defines all required method for the die
 */
public interface IKocka
{
    void hod();
    int getCislo();
}
