package comp;

public interface IMeratelny
{
    double getMiera();
}
