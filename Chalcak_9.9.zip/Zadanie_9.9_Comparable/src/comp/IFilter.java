package comp;

public interface IFilter
{
    boolean akceptuje(Object object);
}
