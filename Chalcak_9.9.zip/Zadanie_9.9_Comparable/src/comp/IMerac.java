package comp;

public interface IMerac
{
    double zmeraj(Object object);
}
